import{a as j,b as J}from"./chunk-BESSACQE.js";import"./chunk-VKSNUBG7.js";import{b as O}from"./chunk-THSMDCAQ.js";import"./chunk-EOBFTUMF.js";import{b as z,d as L,g as q,i as R,k as X}from"./chunk-IHRLAAL3.js";import{Ac as F,Bc as P,Cc as $,Db as T,Ea as s,Gb as r,Hb as _,Ib as b,Jb as v,Kb as x,Lb as h,Mc as W,Oa as C,Pb as B,Ta as M,Ub as f,Vb as I,W as c,Wb as E,X as m,Xa as y,e as S,hb as g,ib as o,jb as n,rb as w,sb as p,tb as u,uc as D,vc as V,xc as N}from"./chunk-D5YQNM6L.js";import{a as k,b as A}from"./chunk-DAQOROHW.js";var Q=()=>[];function H(d,t){if(d&1&&(o(0,"div",32),r(1),n()),d&2){let e=u();s(),b(" ",e.message)}}function Y(d,t){if(d&1){let e=w();o(0,"div",33)(1,"div",34)(2,"input",35),h("ngModelChange",function(l){let a=c(e).$implicit;return x(a.description,l)||(a.description=l),m(l)}),n()(),o(3,"div",36)(4,"input",37),h("ngModelChange",function(l){let a=c(e).$implicit;return x(a.qty,l)||(a.qty=l),m(l)}),n()(),o(5,"div",38)(6,"input",39),h("ngModelChange",function(l){let a=c(e).$implicit;return x(a.price,l)||(a.price=l),m(l)}),n()(),o(7,"button",40),p("click",function(){let l=c(e).index,a=u();return m(a.removeInvoiceItem(l))}),r(8,"X"),n()()}if(d&2){let e=t.$implicit;s(2),v("ngModel",e.description),s(2),v("ngModel",e.qty),s(2),v("ngModel",e.price)}}function K(d,t){if(d&1){let e=w();o(0,"button",41),p("click",function(){c(e);let l=u();return m(l.cancelEdit())}),r(1,"Cancel Edit"),n()}}function Z(d,t){if(d&1){let e=w();o(0,"tr",42)(1,"td",27)(2,"strong"),r(3),n()(),o(4,"td",27),r(5),n(),o(6,"td",27),r(7),f(8,"date"),n(),o(9,"td",43),r(10),f(11,"number"),n(),o(12,"td",28)(13,"span",44),p("click",function(){let l=c(e).$implicit,a=u();return m(a.toggleInvoiceStatus(l))}),r(14),n()(),o(15,"td",29)(16,"div",45)(17,"button",46),p("click",function(){let l=c(e).$implicit,a=u();return m(a.sendEmail(l))}),r(18),n(),o(19,"button",47),p("click",function(){let l=c(e).$implicit,a=u();return m(a.editInvoice(l))}),r(20,"\u270F\uFE0F Edit"),n(),o(21,"button",14),p("click",function(){let l=c(e).$implicit,a=u();return m(a.printInvoice(l))}),r(22,"\u{1F4C4} Print"),n(),o(23,"button",48),p("click",function(){let l=c(e).$implicit,a=u();return m(a.deleteInvoice(l.id))}),r(24,"\u{1F5D1}\uFE0F"),n()()()()}if(d&2){let e=t.$implicit;s(3),_(e.invoice_number),s(2),_(e.client_name),s(2),_(I(8,9,e.issue_date)),s(3),b("$",E(11,11,e.amount,"1.2-2")," "),s(3),T("background",e.status==="Paid"?"#28a745":"#dc3545"),s(),b(" ",e.status," "),s(3),g("disabled",e.sendingEmail),s(),b(" ",e.sendingEmail?"\u23F3 Sending...":"\u{1F4E7} Email"," ")}}function ee(d,t){d&1&&(o(0,"p",49),r(1,"No invoices generated yet."),n())}var U=class d{constructor(t,e){this.cms=t;this.route=e}contents=[];invoices=new S([]);editableClients$=new S([]);message="";editingInvoiceId=null;newInvoice={invoice_number:"INV-"+Date.now().toString().slice(-6),client_name:"",issue_date:new Date().toISOString().split("T")[0],amount:0,status:"Pending",items:[{description:"",qty:1,price:0}]};ngOnInit(){this.loadInvoices(),this.loadClients(),this.route.queryParams.subscribe(t=>{t.client&&(this.newInvoice.client_name=t.client)})}loadClients(){this.cms.getContent().subscribe(t=>{this.contents=t;let e=this.contents.find(i=>i.content_key==="clients_list");if(e){console.log(JSON.parse(e.content_value));try{this.editableClients$.next(JSON.parse(e.content_value))}catch{this.editableClients$.next([])}}})}loadInvoices(){this.cms.getInvoices().subscribe(t=>{this.invoices.next(t.map(e=>A(k({},e),{items:typeof e.items=="string"?JSON.parse(e.items):e.items})))})}addInvoiceItem(){this.newInvoice.items.push({description:"",qty:1,price:0})}removeInvoiceItem(t){this.newInvoice.items.splice(t,1)}calculateTotal(){return this.newInvoice.amount=this.newInvoice.items.reduce((t,e)=>t+e.qty*e.price,0),this.newInvoice.amount}saveInvoice(){this.calculateTotal(),this.editingInvoiceId?this.cms.updateInvoice(this.editingInvoiceId,this.newInvoice).subscribe(()=>{this.showMessage("Invoice updated successfully!"),this.loadInvoices(),this.cancelEdit()}):this.cms.createInvoice(this.newInvoice).subscribe(()=>{this.showMessage("Invoice generated successfully!"),this.loadInvoices(),this.cancelEdit()})}editInvoice(t){this.editingInvoiceId=t.id,this.newInvoice={invoice_number:t.invoice_number,client_name:t.client_name,issue_date:new Date(t.issue_date).toISOString().split("T")[0],amount:t.amount,status:t.status,items:JSON.parse(JSON.stringify(t.items))},window.scrollTo({top:0,behavior:"smooth"})}cancelEdit(){this.editingInvoiceId=null,this.newInvoice={invoice_number:"INV-"+Date.now().toString().slice(-6),client_name:"",issue_date:new Date().toISOString().split("T")[0],amount:0,status:"Pending",items:[{description:"",qty:1,price:0}]}}deleteInvoice(t){confirm("Are you sure you want to delete this invoice?")&&this.cms.deleteInvoice(t).subscribe(()=>{this.showMessage("Invoice deleted"),this.loadInvoices()})}toggleInvoiceStatus(t){let e=t.status==="Paid"?"Pending":"Paid";this.cms.updateInvoiceStatus(t.id,e).subscribe(()=>{t.status=e,this.showMessage(`Invoice #${t.invoice_number} marked as ${e}`)})}sendEmail(t){t.sendingEmail=!0,this.cms.sendInvoiceEmail(t.id).subscribe({next:e=>{this.showMessage(e.message||"Invoice email sent successfully!"),t.sendingEmail=!1},error:e=>{let i=e.error?.message||e.error?.error||e.message||"Failed to send email";this.showMessage("Error: "+i),t.sendingEmail=!1}})}printInvoice(t){let e=this.editableClients$.value.find(a=>a.name===t.client_name),i=window.open("","_blank");if(!i)return;let l=t.items.map((a,G)=>`
        <tr style="background: ${G%2===0?"#fff":"#ffe9da"};">
            <td style="padding: 12px; border-bottom: 1px solid #ddd; font-weight: 500;">${a.description}</td>
            <td style="padding: 12px; border-bottom: 1px solid #ddd; text-align: center;">${a.qty||""}</td>
            <td style="padding: 12px; border-bottom: 1px solid #ddd; text-align: right; font-weight: 500;">${Number(a.price*(a.qty||1)).toLocaleString(void 0,{minimumFractionDigits:2})}</td>
        </tr>
    `).join("");i.document.write(`
        <html>
            <head>
                <title>Eriline Invoice - ${t.invoice_number}</title>
                <style>
                    @page { size: A4; margin: 0; }
                    body { 
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                        margin: 0; 
                        padding: 0;
                        -webkit-print-color-adjust: exact;
                        color: #333;
                    }
                    .a4-container {
                        width: 210mm;
                        min-height: 297mm;
                        margin: auto;
                        background: #fff;
                        position: relative;
                        display: flex;
                        flex-direction: column;
                    }
                    .top-header {
                        height: 120px;
                        display: flex;
                        align-items: flex-end;
                        position: relative;
                        overflow: hidden;
                    }
                    .header-accent-yellow {
                        position: absolute;
                        top: 0; left: 0;
                        width: 45%;
                        height: 100px;
                        background: #F2A93B;
                        clip-path: polygon(0 0, 90% 0, 100% 100%, 0% 100%);
                    }
                    .header-accent-navy {
                        position: absolute;
                        top: 20px; left: 40%;
                        width: 60%;
                        height: 80px;
                        background: #0A214D;
                        clip-path: polygon(10% 0, 100% 0, 100% 100%, 0% 100%);
                    }
                    .header-logo-container {
                        position: absolute;
                        top: 25px;
                        left: 50px;
                        z-index: 10;
                        background: #0A214D;
                        padding: 10px 20px;
                        border-radius: 4px;
                        border-left: 8px solid #F2A93B;
                    }
                    .date-box {
                        position: absolute;
                        top: 70px;
                        right: 0;
                        background: #e9ecef;
                        padding: 8px 40px;
                        font-weight: 500;
                        font-size: 14px;
                    }
                    .client-info {
                        padding: 40px 60px;
                        font-size: 15px;
                        line-height: 1.6;
                    }
                    .items-table {
                        width: calc(100% - 120px);
                        margin: 0 60px;
                        border-collapse: collapse;
                    }
                    .items-table th {
                        background: #f18c35;
                        color: white;
                        text-align: left;
                        padding: 12px;
                        font-size: 18px;
                        text-transform: uppercase;
                    }
                    .totals-section {
                        margin: 20px 60px;
                        display: flex;
                        flex-direction: column;
                        align-items: flex-end;
                    }
                    .totals-row {
                        display: grid;
                        grid-template-columns: 150px 150px;
                        text-align: right;
                        padding: 5px 0;
                    }
                    .note-box {
                        margin: 40px 60px;
                        border: 1.5px solid #f18c35;
                        padding: 15px 25px;
                        border-radius: 4px;
                    }
                    .footer-info {
                        margin-top: auto;
                        padding: 40px 60px;
                        display: flex;
                        flex-direction: column;
                        align-items: flex-end;
                        font-size: 14px;
                        font-weight: 500;
                    }
                    .footer-accent {
                        height: 30px;
                        display: flex;
                    }
                    .footer-yellow { background: #F2A93B; flex: 1; clip-path: polygon(10% 0, 100% 0, 100% 100%, 0% 100%); }
                    .footer-navy { background: #0A214D; width: 40%; }
                    
                    @media print {
                        .no-print { display: none; }
                        body { margin: 0; }
                    }
                </style>
            </head>
            <body>
                <div class="a4-container">
                    <div class="top-header">
                        <div class="header-accent-yellow"></div>
                        <div class="header-accent-navy"></div>
                        <div class="header-logo-container">
                            <img src="${window.location.origin}/logo.png" style="height: 45px; display: block;">
                        </div>
                        <div class="date-box">
                            Date: ${new Date(t.issue_date).toLocaleDateString("en-GB")}
                        </div>
                    </div>

                    <div class="client-info">
                        <p style="margin-bottom: 5px;">To,</p>
                        <h2 style="margin: 0; color: #000;">${t.client_name}</h2>
                        ${e&&e.address?`<p style="white-space: pre-line; margin: 5px 0;">${e.address}</p>`:""}
                        ${e&&e.phone?`<p style="margin: 5px 0; display: inline-block;">${e.phone}</p>`:""}
                        ${e&&e.email?`<p style="margin: 5px 0;">${e.email}</p>`:""}
                    </div>

                    <table class="items-table" style="width: calc(100% - 120px); margin: 0 60px; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th style="width: 65%; text-align: left; padding: 12px; background: #f18c35; color: white;">Description</th>
                                <th style="text-align: center; width: 15%; padding: 12px; background: #f18c35; color: white;">QTY</th>
                                <th style="text-align: right; width: 20%; padding: 12px; background: #f18c35; color: white;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${l}
                            <tr style="height: 40px;"><td></td><td></td><td></td></tr>
                        </tbody>
                    </table>

                    <div class="totals-section">
                        <div class="totals-row">
                            <span style="color: #666;">Total</span>
                            <span style="font-weight: bold;">${Number(t.amount).toLocaleString(void 0,{minimumFractionDigits:2})}</span>
                        </div>
                        <div class="totals-row">
                            <span style="color: #666;">Paid</span>
                            <span>-0.00</span>
                        </div>
                         <div class="totals-row" style="border-top: 1px solid #ddd; margin-top: 5px; padding-top: 10px; font-size: 20px;">
                            <span style="font-weight: bold;">Total</span>
                            <span style="font-weight: bold; color: #0A214D;">${Number(t.amount).toLocaleString(void 0,{minimumFractionDigits:2})}</span>
                        </div>
                    </div>

                    <div class="note-box">
                        <strong style="color: #d9534f; font-size: 18px;">Note:</strong>
                        <ul style="margin: 10px 0; color: #444;">
                            <li>Thank you for choosing Eriline Software Solutions.</li>
                            <li>Payments are due within 15 days of issue.</li>
                        </ul>
                    </div>

                    <div class="footer-info">
                        <p style="margin: 5px 0;">roshansiva1991@gmail.com \u2709\uFE0F</p>
                        <p style="margin: 5px 0;">+94719195591 \u{1F4DE}</p>
                        <p style="margin: 5px 0;">Eriline.lk / Eriline.co \u{1F310}</p>
                    </div>

                    <div class="footer-accent">
                        <div style="background: #0A214D; width: 50%;"></div>
                        <div style="background: #F2A93B; flex: 1; clip-path: polygon(15% 0, 100% 0, 100% 100%, 0% 100%);"></div>
                    </div>

                    <div class="no-print" style="position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);">
                         <button onclick="window.print()" style="padding: 15px 40px; background: #0A214D; color: white; border: none; border-radius: 50px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">\u{1F5A8}\uFE0F PRINT INVOICE / SAVE PDF</button>
                    </div>
                </div>
            </body>
        </html>
    `),i.document.close()}showMessage(t){this.message=t,setTimeout(()=>this.message="",3e3)}trackByIndex(t,e){return t}static \u0275fac=function(e){return new(e||d)(C(W),C(O))};static \u0275cmp=M({type:d,selectors:[["app-admin-billing"]],decls:64,vars:22,consts:[[1,"dash-section","glass-card"],[1,"flex-between","mb-2"],[1,"badge"],["class","alert-success animate-fade-in","style","margin-bottom: 1.5rem; padding: 0.8rem; background: rgba(40, 167, 69, 0.2); border: 1px solid #28a745; border-radius: 8px;",4,"ngIf"],[1,"invoice-creator","glass-card","mb-2",2,"background","rgba(10, 33, 77, 0.2)","border","1px solid var(--accent)","padding","1.5rem","border-radius","12px"],[1,"mb-1",2,"font-size","1.1rem","border-bottom","1px solid var(--glass-border)","padding-bottom","0.5rem","margin-bottom","1rem"],[1,"grid-3","mb-1"],[1,"input-group"],["bindLabel","name","bindValue","name","placeholder","Select a Client","appendTo","body","panelClass","custom-dark-dropdown-panel",1,"custom-dark-select",3,"ngModelChange","items","ngModel"],["placeholder","INV-XXXXXX",3,"ngModelChange","ngModel"],["type","date",3,"ngModelChange","ngModel"],[1,"items-table","mt-2"],[1,"flex-between","mb-1",2,"border-bottom","1px solid var(--glass-border)","padding-bottom","0.5rem"],[2,"font-size","0.85rem","font-weight","600","color","var(--text-secondary)"],[1,"btn-primary","btn-xs",3,"click"],["class","row-items","style","display: flex; gap: 0.8rem; align-items: center; margin-bottom: 0.8rem;",4,"ngFor","ngForOf","ngForTrackBy"],[1,"flex-between","mt-2","pt-2",2,"border-top","1px solid var(--glass-border)"],[1,"total-preview"],[2,"color","var(--text-secondary)"],[2,"color","var(--accent)","font-size","1.4rem","font-weight","700","margin-left","0.5rem"],[2,"display","flex","gap","10px"],["class","btn-outline",3,"click",4,"ngIf"],[1,"btn-primary",3,"click","disabled"],[1,"mb-1",2,"font-size","1.2rem","border-bottom","1px solid var(--glass-border)","padding-bottom","0.5rem","margin-top","2rem"],[1,"invoice-list","mt-1"],[1,"w-full",2,"border-collapse","collapse","text-align","left","width","100%"],[2,"border-bottom","2px solid var(--glass-border)","color","var(--text-secondary)","font-size","0.8rem"],[2,"padding","0.8rem 0.5rem"],[2,"padding","0.8rem 0.5rem","text-align","center"],[2,"padding","0.8rem 0.5rem","text-align","right"],["style","border-bottom: 1px solid var(--glass-border); transition: var(--transition);",4,"ngFor","ngForOf"],["class","empty-state mt-2",4,"ngIf"],[1,"alert-success","animate-fade-in",2,"margin-bottom","1.5rem","padding","0.8rem","background","rgba(40, 167, 69, 0.2)","border","1px solid #28a745","border-radius","8px"],[1,"row-items",2,"display","flex","gap","0.8rem","align-items","center","margin-bottom","0.8rem"],[1,"input-group",2,"flex","3"],["placeholder","Description (e.g. Monthly Maintenance)",3,"ngModelChange","ngModel"],[1,"input-group",2,"flex","0.8"],["type","number","placeholder","Qty",3,"ngModelChange","ngModel"],[1,"input-group",2,"flex","1.2"],["type","number","placeholder","Price",3,"ngModelChange","ngModel"],[1,"btn-danger","btn-xs",2,"height","40px","padding","0 1rem",3,"click"],[1,"btn-outline",3,"click"],[2,"border-bottom","1px solid var(--glass-border)","transition","var(--transition)"],[2,"padding","0.8rem 0.5rem","color","var(--accent)","font-weight","600"],["title","Click to toggle status",1,"badge",2,"cursor","pointer","user-select","none",3,"click"],[2,"display","flex","gap","0.5rem","justify-content","flex-end"],[1,"btn-outline","btn-xs",3,"click","disabled"],[1,"btn-outline","btn-xs",3,"click"],[1,"btn-danger","btn-xs",3,"click"],[1,"empty-state","mt-2"]],template:function(e,i){e&1&&(o(0,"section",0)(1,"div",1)(2,"h3"),r(3,"Invoice Generator"),n(),o(4,"span",2),r(5,"PRO VERSION"),n()(),y(6,H,2,1,"div",3),o(7,"div",4)(8,"h4",5),r(9),n(),o(10,"div",6)(11,"div",7)(12,"label"),r(13,"Client Name"),n(),o(14,"ng-select",8),f(15,"async"),h("ngModelChange",function(a){return x(i.newInvoice.client_name,a)||(i.newInvoice.client_name=a),a}),n()(),o(16,"div",7)(17,"label"),r(18,"Invoice #"),n(),o(19,"input",9),h("ngModelChange",function(a){return x(i.newInvoice.invoice_number,a)||(i.newInvoice.invoice_number=a),a}),n()(),o(20,"div",7)(21,"label"),r(22,"Issue Date"),n(),o(23,"input",10),h("ngModelChange",function(a){return x(i.newInvoice.issue_date,a)||(i.newInvoice.issue_date=a),a}),n()()(),o(24,"div",11)(25,"div",12)(26,"label",13),r(27,"LINE ITEMS"),n(),o(28,"button",14),p("click",function(){return i.addInvoiceItem()}),r(29,"+ Add Item"),n()(),y(30,Y,9,3,"div",15),n(),o(31,"div",16)(32,"div",17)(33,"strong",18),r(34,"Total Amount: "),n(),o(35,"span",19),r(36),f(37,"number"),n()(),o(38,"div",20),y(39,K,2,0,"button",21),o(40,"button",22),p("click",function(){return i.saveInvoice()}),r(41),n()()()(),o(42,"h3",23),r(43," Recent Invoices"),n(),o(44,"div",24)(45,"table",25)(46,"thead")(47,"tr",26)(48,"th",27),r(49,"# NUMBER"),n(),o(50,"th",27),r(51,"CLIENT"),n(),o(52,"th",27),r(53,"DATE"),n(),o(54,"th",27),r(55,"AMOUNT"),n(),o(56,"th",28),r(57,"STATUS"),n(),o(58,"th",29),r(59,"ACTIONS"),n()()(),o(60,"tbody"),y(61,Z,25,14,"tr",30),f(62,"async"),n()(),y(63,ee,2,0,"p",31),n()()),e&2&&(s(6),g("ngIf",i.message),s(3),b(" ",i.editingInvoiceId?"Edit Invoice":"Create New Invoice"),s(5),g("items",I(15,14,i.editableClients$)||B(21,Q)),v("ngModel",i.newInvoice.client_name),s(5),v("ngModel",i.newInvoice.invoice_number),s(4),v("ngModel",i.newInvoice.issue_date),s(7),g("ngForOf",i.newInvoice.items)("ngForTrackBy",i.trackByIndex),s(6),b("$",E(37,16,i.calculateTotal(),"1.2-2")),s(3),g("ngIf",i.editingInvoiceId),s(),g("disabled",!i.newInvoice.client_name||i.newInvoice.amount<=0),s(),_(i.editingInvoiceId?"Update Invoice":"Generate & Save Invoice"),s(20),g("ngForOf",I(62,19,i.invoices)),s(2),g("ngIf",i.invoices.length===0))},dependencies:[$,D,V,X,z,R,L,q,J,j,N,P,F],encapsulation:2})};export{U as AdminBillingComponent};
